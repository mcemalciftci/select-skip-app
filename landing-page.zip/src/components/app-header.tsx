
const AppHeader = () => {
  return (
     <h1 className="text-xl font-semibold">My App</h1>
  )
}

export default AppHeader