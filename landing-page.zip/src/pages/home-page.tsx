import Stepper from "@/components/Stepper"


export const HomePage = () => {
  return (
    <div className="">
      <Stepper />
    </div>
  )
}
