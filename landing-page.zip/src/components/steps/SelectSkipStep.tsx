import { useEffect, useState } from "react"
import SelectSkipCard from "../select-skip-card"

export const SelectSkipStep = () => {
  const [data, setData] = useState<any>(null)
  useEffect(() => {
    fetch("https://app.wewantwaste.co.uk/api/skips/by-location?postcode=NR32&area=Lowestoft").then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.json()
    }).then((data) => {
      setData(data)
    }).catch((error) => {
      console.error("There was a problem with the fetch operation:", error)
    })
   
  }, []) 
  
  return (
          <div className="text-white grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4  mb-40  w-full">
            <SelectSkipCard cardDatas={data} />
          </div>
  )
}
